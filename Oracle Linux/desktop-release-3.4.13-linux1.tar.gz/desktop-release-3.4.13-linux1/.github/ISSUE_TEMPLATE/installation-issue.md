---
name: "\U0001F4BB Installation issue"
about: Report a problem when installing the application
title: ''
labels: ''
assignees: ''

---

### Operating System/Distribution

Which distribution of Linux are you using?

### Installer

Which version of the app?
Which installer type?

### What happened?

Provide as much detail as possible. Error messages or output are extremely useful.
