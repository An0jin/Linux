const markdownlintGitHub = require('@github/markdownlint-github')
module.exports = markdownlintGitHub.init()
